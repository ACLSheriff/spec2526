<?php

if (!isset($_GET['message'])) {//checks if message is set
    session_start();//will allow session to start
    $message = false;//and send a message
} else {//error handle
    $message = htmlspecialchars(urldecode($_GET["message"]));//will decode message into string
}

require_once "assests/dbconnect.php";//gets file dbconnect
require_once "assests/common.php";

echo "<!DOCTYPE html>";//required tag
echo "<html>";//opens page content
echo "<head>";//opens the head of the code

echo "<title> home page </title>";//titles the page
echo "<link rel='stylesheet' type='text/css' href='css/stylesheet.css'/>";//links to style sheet

echo "</head>";// closes the head of the page
echo "<body>";//opens the body of the page

echo "<div class='container'>";//dive alows you to split your page up and class allows you to style that div

require_once "assests/topbar.php";// gets and displays the top bar
require_once "assests/navbar.php";// gets and displays nav bar

echo "<div class='content'>";// this class is a box that i can put content for my page into

echo "<h2> Rolsa technologies </h2>";

echo "<br>";
//paragh text
echo "<p> We believe small changes can make a big difference. Green technology helps us live more sustainably </p>";
echo "<p> using innovation to protect the planet while improving daily life. </p>";
echo "<p> From renewable energy like solar and wind, to energy-efficient appliances and eco-friendly materials, </p>";
echo "<p> green tech offers smart ways to cut down on waste and pollution. </p>";

echo "<br>";

echo "<h3> Here are a few simple ways you can reduce your carbon footprint today: </h3>";
echo "<table>";//starts a table
echo "<ul>";//bullit points the list
//these are all items in the list
echo "<li> Switch to renewable energy, choose solar panels or green power plans if available. </li>";//items in list
echo "<li> Use energy-efficient devices, look for appliances with high energy ratings. </li>";
echo "<li> Reduce, reuse, recycle. minimize waste and give products a second life. </li>";
echo "<li> Choose sustainable transport, walk, bike, carpool, or go electric when possible. </li>";
echo "<li> Conserve water and power, small habits like turning off lights make a big impact. </li>";
echo "<ul>";// end of list
echo "</table>";//end of table

echo "<br>";

echo "<p> Together, we can build a cleaner, greener future, one innovation at a time. </p>";

echo "<br>";//breaks for readablity

//echo "<img id='text' src='images/text.jfif' alt='text' />";

echo "<br>";



if (!$message) {//checks message
    echo user_message();//print out message from subroutine
}else {
    echo $message;//prints message
}



try{//error handle
    $conn = dbconnect_insert();
    echo "succsess";//if it works prints succsess message
} catch (PDOException $e) {//catches any other error
    echo $e->getMessage();
}

echo "</div>";//closes each class
echo "</div>";
echo "</body>";// closes the body of code
echo "</html>";// end of html code
?>
<?php

session_start();

require_once "assests/dbconnect.php";//gets file dbconnect
require_once "assests/common.php";


if (!isset($_SESSION['userid'])) {//if the user id is not set
    $_SESSION['usermessage'] = "you are not logged in";///checks if user is already logged in and will return message if so
    header("location:index.php");//returns to home page
    exit;//stop further exicution
}

echo "<!DOCTYPE html>";//required tag
echo "<html>";//opens page content
echo "<head>";//opens the head of the code

echo "<title> products </title>";//titles the page
echo "<link rel='stylesheet' type='text/css' href='css/stylesheet.css'/>";//links to style sheet

echo "</head>";// closes the head of the page
echo "<body>";//opens the body of the page

echo "<div class='container'>";//dive alows you to split your page up and class allows you to style that div

require_once "assests/topbar.php";// gets and displays the top bar
require_once "assests/navbar.php";// gets and displays nav bar

echo "<div class='content'>";// this class is a box that i can put content for my page into

echo "<h2> Rolsa technologies </h2>";

echo "<br>";
//paragh text
echo "<p> We believe small changes can make a big difference. Green technology helps us live more sustainably </p>";

echo "<br>";

echo "<table id='solar pannels'>";//starts a table for bookings

echo "<tr>";
echo "<td> "."Solar pannels"."</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt is
echo "<td> price : " ."£90 per pannel". "</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt was made
echo "<td> description : " ." with solar pannels you can: Generate your own renewable energy, store engy for later, and save money" . "</td>";//will show the docters surname

echo "</tr>";
echo "</form>";//closes form and table

echo "<br>";

echo "<table id='electric car chargers'>";//starts a table for bookings

echo "<tr>";
echo "<td> "."electric car chargers"."</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt is
echo "<td> price : " ."£1000 for installation". "</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt was made
echo "<td> description : " ."EV chargers provide electric power to recharge electric vehicle batteries quickly and efficiently. No more fuel! " . "</td>";//will show the docters surname

echo "<br>";

echo "<table id='home en'>";//starts a table for bookings

echo "<tr>";
echo "<td> "."smart plugs and switches"."</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt is
echo "<td> price : " ."rages depding on needs, but for the hole house installation can be up to £3000 ". "</td>";//using a built in fuction and telling it what format our epoch time should go in for when the apt was made
echo "<td> description : " ." Smart plugs and switches let you control and monitor the power usage of plugged-in devices and lighting  remotely." . "</td>";//will show the docters surname


echo "</tr>";
echo "</form>";//closes form and table




echo "<br>";




echo "</div>";//closes each class
echo "</div>";
echo "</body>";// closes the body of code
echo "</html>";// end of html code
?>
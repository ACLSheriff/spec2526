<?php
echo "<div class='topbar'>";//difines this as the top bar in a class
echo "<img id='text' src='images/greenlogo.webp' alt='text' />";  #sets a logo up for the top of each page
echo "<br>";  # line break for clarity and easy of reading.
echo "<br>";  # line break for clarity and easy of reading.
echo "</div>";//closes class